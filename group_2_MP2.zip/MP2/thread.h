/*this file contains the functions used to interact with dispatching thread*/

/* this function is used to initialize dispatching thread. Should be called in init function of the module*/
int thread_init (void);

/*this function is used to clean dispatching thread*/
void thread_cleanup(void);
int wake_thread(void);
